'''
Dictionary of softness sensitive BVS parameters
R_0 and b

These parameters are taken from the following paper:
S. Adams 
"Relationship between bond valence and bond softness of alkali halides and chalcogenide" 
Acta Crystallogr. Sect. B 57(3), 278--287 (2001).
'''
dict_BVS = {"LiO":[1.1725, 0.515],
            "NaO":[1.5602, 0.483],
            "LiF":[1.1011, 0.501],
            "NaF":[1.4262, 0.475],
            "LiS":[1.5070, 0.632],
            "NaS":[1.8311, 0.621]}
