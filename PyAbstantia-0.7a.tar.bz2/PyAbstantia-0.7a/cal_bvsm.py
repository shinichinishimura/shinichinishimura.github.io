''' BVS map calculation '''
import sys
from os import path
from ctypes import POINTER, byref, c_double
from ctypes import c_int, c_void_p, c_int64
from numpy import array, dot, zeros, ndenumerate, float64, ctypeslib, ndindex
from numpy import r_, c_, vstack, hstack, int64, apply_along_axis
from math import radians, sin, cos, sqrt

BVSLIB = 'bvs.so'
try:
    bvs_ctypes = ctypeslib.load_library(BVSLIB, path.abspath(path.dirname(__file__)))
except OSError:
    print('PyAbstantia could not load bvs.so.')
    sys.exit()

bvs_ctypes.calbvs_.argtypes = [
    POINTER(c_double),
    POINTER(c_double),
    POINTER(c_double),
    ctypeslib.ndpointer(dtype=float64),
    POINTER(c_int),
    ctypeslib.ndpointer(dtype=float64)]
bvs_ctypes.calbvs_.restype = c_void_p

def latmat(latp):
    ''' Lattice Matrix '''
    _a, _b, _c, _al, _be, _ga = latp
    _alr, _ber, _gar = radians(_al), radians(_be), radians(_ga)
    _v = _a*_b*_c*sqrt(1 - cos(_alr)**2 - cos(_ber)**2 - cos(_gar)**2 +
                       2*cos(_alr)*cos(_ber)*cos(_gar))
    _l1, _l2, _l3 = _a, 0, 0
    _m1, _m2, _m3 = _b*cos(_gar), _b*sin(_gar), 0
    _n1 = _c*cos(_ber)
    _n2 = _c*(cos(_alr)-cos(_ber)*cos(_gar))/sin(_gar)
    _n3 = _v/(_a*_b*sin(_gar))
    return array([[_l1, _m1, _n1],
                  [_l2, _m2, _n2],
                  [_l3, _m3, _n3]], dtype=float64)

def standardize(x):
    if x < 0.0:
        x += 1.0
    elif x > 1.0:
        x -= 1.0
    return x

def gencilst(atmlst, latp, lmat, cion):
    expn = [1. if axis > 6.0 else 2. for axis in latp[:3]]
    unit = zeros((4, 0), dtype=float64)
    for site in atmlst:
        if site[0] == cion:
            site[1] = [standardize(x) for x in site[1]]
            unit = c_[unit, r_[site[1], site[2]]]
    cilst = zeros((4, 0), dtype=float64)
    _ai, _bi, _ci = -expn[0], -expn[1], -expn[2]
    while _ai <= expn[0]:
        while _bi <= expn[1]:
            while _ci <= expn[2]:
                shifted = unit.copy()
                shifted[:3, :] += array([_ai, _bi, _ci]).reshape(3, 1)
                cilst = c_[cilst, shifted]
                _ci += 1.
            _ci = -expn[2]
            _bi += 1.
        _bi = -expn[1]
        _ai += 1.
    cilst[:3, :] = dot(lmat, cilst[:3, :])
    return cilst.T.copy()

def calbvm(bvprm, cilst, grxyz):
    ''' Returns BVS map '''
    # definitions for ctypes
    bvs = c_double(0.0)
    rzr = c_double(bvprm[0])  # R_0
    bbv = c_double(1/bvprm[1])  # 1/B
    cnum = c_int(cilst.shape[0])  # Number of counter ion
    bvm = zeros(grxyz.shape[1:])  # 3D array for BVS
    for idx in ndindex(bvm.shape):
        # BVS calculation
        bvs_ctypes.calbvs_(byref(bvs), byref(rzr), byref(bbv),
                           grxyz[:, idx[0], idx[1], idx[2]].copy(),
                           byref(cnum), cilst)
        bvm[idx] = bvs.value
    return bvm

def point_bvs(pcart, bvprm, cilst):
    ''' Return single point BVS '''
    # definitions for ctypes
    bvs = c_double(0.0)
    rzr = c_double(bvprm[0])  # R_0
    bbv = c_double(1/bvprm[1])  # 1/B
    cnum = c_int(cilst.shape[0])  # Number of counter ion
    pcart = array(pcart, dtype=float64)
    # BVS calculation
    bvs_ctypes.calbvs_(byref(bvs), byref(rzr), byref(bbv),
                       pcart, byref(cnum), cilst)
    return bvs.value
