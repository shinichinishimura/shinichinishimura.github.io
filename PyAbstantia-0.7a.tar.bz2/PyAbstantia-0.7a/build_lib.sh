#!/bin/bash
# Set Fortran compiler
#FC=gfortran
FC=ifort

# For gfortran
OPT="-O2"
ARCH="-march=native"
#ARCH=""
#LINK="-shared -fPIC -static-libgcc -static-libgfortran"
LINK="-shared -fPIC"

# For Intel Compiler
if [ ${FC} = "ifort" ]; then
    OPT="-O3"
    ARCH="-xHost"
    LINK="-shared -fPIC"
fi

#f2py -c --f90exec=${FC} --opt="${OPT}" --arch=${ARCH} ${LINK} ./src/bvs_f2py.f90 -m bvs_f2py
#f2py -c --f90exec=${FC} --opt="${OPT}" --arch=${ARCH} ${LINK} ./src/bvel_f2py.f90 -m bvel_f2py
sources=(bvs bvel)
for src in ${sources[@]}; do
    ${FC} ${OPT} ${ARCH} ${LINK} -o ${src}.so src/${src}.f90
done
