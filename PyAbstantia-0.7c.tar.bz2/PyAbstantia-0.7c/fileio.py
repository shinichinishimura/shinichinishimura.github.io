''' fileio.py '''
# -*- coding: utf-8 -*-
from struct import pack
import sys
import warnings
import numpy as np
from numpy import array

def _input_str():
    if sys.version_info.major < 3:
        return raw_input()
    return input()

class ReadCIF(object):
    ''' Read CIF by CifParser of pymatgen '''
    def __parse_cif(self, fname):
        try:
            from pymatgen.io.cif import CifParser
        except ImportError:
            print('Pymatgen was not found.\nInstall pymatgen for handling CIF.')
            sys.exit()

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            cifp = CifParser(fname)

        struct = cifp.get_structures(primitive=False)[0]
        self.latp = struct.lattice.abc + struct.lattice.angles

        for site in struct.sites:
            if len(site.species_string.split(',')) > 1:
                for species in site.species_string.split(','):
                    items = species.strip().split(':')
                    self.atmlst.append(list([items[0],
                                             site.frac_coords,
                                             float(items[1])]))
            else:
                self.atmlst.append(list([_sp_occ(site)[0],
                                         site.frac_coords,
                                         float(_sp_occ(site)[1])]))

    def __set_resolution(self):
        # resolution
        if '-r' in sys.argv:
            try:
                incr = float(sys.argv[sys.argv.index('-r')+1])
                self.resl = [int(x/incr) if int(x/incr)%2 == 0 else int(x/incr)+1
                             for x in self.latp[:3]]
            except ValueError:
                self.resl = [int(x/0.1) if int(x/0.1)%2 == 0 else int(x/0.1)+1
                             for x in self.latp[:3]]
            print('Resolution was set as {} {} {}'.format(*self.resl))
        else:
            print('Input numbers of voxels along a, b and c axes.')
            self.resl = [int(x) for x in _input_str().split()]

    def __set_bv_param(self):
        for i in range(self.cinum):
            print('Input counter ion species {} of {}'.format(i+1, self.cinum))
            self.cisp[i] = _input_str().strip()
            if '-a' in sys.argv:
                try:
                    from dict_BVS import dict_BVS
                except ImportError:
                    print("BVS paramter dictionary was not found.")
                    sys.exit()
                try:
                    self.bvplst[i] = dict_BVS[self.t_ion + self.cisp[i]]
                except KeyError:
                    print('The BVS parameters were not found in the dictionary.')
                    print('Input manually.')
                    print('Example:')
                    print('1.5602 0.475')
                    self.bvplst[i] = [float(x) for x in _input_str().split()]
            else:
                print('Input BV parameters R_0 and b')
                print('Example:')
                print('1.5602 0.475')
                self.bvplst[i] = [float(x) for x in _input_str().split()]

    def __set_bvel_param(self):
        try:
            from dict_R_cov import dict_R_cov, dict_form_charge
            from dict_BVEL import dict_BVEL
        except ImportError as err:
            print(err)
            sys.exit()

        for site in self.atmlst:
            if site[0] not in self.ion_name:
                self.ion_name.append(site[0])

        self.t_charge = dict_form_charge[self.t_ion]
        self.t_rcov = dict_R_cov[self.t_ion]

        for ion in self.ion_name:
            try:
                self.d_0.append(dict_BVEL[self.t_ion+ion][0])
                self.rmin.append(dict_BVEL[self.t_ion+ion][1])
                self.alpha.append(dict_BVEL[self.t_ion+ion][2])
            except KeyError:
                self.d_0.append(0.0)
                self.rmin.append(0.0)
                self.alpha.append(0.0)
            try:
                self.rcov.append(dict_R_cov[ion])
            except KeyError:
                print('{} was not found in the dictionary'.format(ion))
                self.rcov.append(0.0)
            try:
                self.formal_charge.append(dict_form_charge[ion])
            except KeyError:
                self.formal_charge.append(0.0)

    def __init__(self, fname):
        print('--- CIF mode ---')
        self.flag_bvel = False
        try:
            with open(fname, 'r') as cif:
                for line in cif:
                    if line.startswith('data_'):
                        self.title = "_".join(line.strip().split('_')[1:])
                        break
        except IOError as err:
            print(err)
            sys.exit()

        self.latp = np.zeros(6)
        self.atmlst = list()
        self.__parse_cif(fname)  # Parse CIF

        print('Input target ion')
        self.t_ion = _input_str().strip()
        print('Input a formal valence number of target ion.')
        self.ival = float(_input_str())
        print('Input a number of species for counter ion.')
        self.cinum = int(_input_str())

        self.cisp = [0] * self.cinum  # ionic species
        self.bvplst = [0] * self.cinum  # BVS parameters
        self.__set_bv_param()

        self.resl = np.zeros(3)
        self.__set_resolution()

        # parameters for BVEL
        self.t_charge = 0.0
        self.t_rcov = 0.0
        self.ion_name = list()
        self.formal_charge = list()
        self.d_0 = list()
        self.rmin = list()
        self.alpha = list()
        self.rcov = list()

    def write_inp(self, fname):
        ''' Write *.inp file '''
        _f = open(fname, 'w')
        _f.write(self.title+'\n')
        _f.write('{} {} {} {} {} {}\n'.format(*self.latp))
        _f.write('{}\n'.format(self.ival))
        _f.write('{}\n'.format(self.cinum))

        for i in range(self.cinum):
            _f.write('{} '.format(self.cisp[i]))
            _f.write('{} {}\n'.format(*self.bvplst[i]))

        _f.write('{} {} {}\n'.format(*self.resl))

        for site in self.atmlst:
            items = [site[0], site[1][0], site[1][1], site[1][2], site[2]]
            _f.write('{:<4} {:8.5f} {:8.5f} {:8.5f} {:6.3f}\n'.format(*items))

        _f.close()

    def write_bvel_inp(self, fname):
        ''' Write *.inp for BVEL '''
        self.__set_bvel_param()  # Set BVEL parameters
        _f = open(fname, 'w')
        _f.write(self.title+' BVEL\n')
        _f.write('{} {} {} {} {} {}\n'.format(*self.latp))
        _f.write('{}\n'.format(self.t_ion))
        _f.write('{}\n'.format(self.t_charge))
        _f.write('{}\n'.format(self.t_rcov))  # Covalent radius of target ion
        _f.write('{}\n'.format(len(self.ion_name)))
        _f.write(' '.join([str(x) for x in self.formal_charge]) + '\n')
        _f.write(' '.join([str(x) for x in self.d_0]) + '\n')
        _f.write(' '.join([str(x) for x in self.rmin]) + '\n')
        _f.write(' '.join([str(x) for x in self.alpha]) + '\n')
        _f.write(' '.join([str(x) for x in self.rcov]) + '\n')

        _f.write('{} {} {}\n'.format(*self.resl))

        for site in self.atmlst:
            items = [site[0], site[1][0], site[1][1], site[1][2], site[2]]
            _f.write('{:<4} {:8.5f} {:8.5f} {:8.5f} {:6.3f}\n'.format(*items))

        _f.close()

def _sp_occ(psite):
    species = psite.species_string
    if ':' in species:
        return species.split(':')
    return [species, '1.0']

def _readinpline(file):
    ''' Read a line after skiping blank lines and comments '''
    for line in file:
        if line.isspace() or line.strip()[0] == '#':
            continue
        else:
            return line.rstrip()

def _normalize(atmlst):
    ''' Normalization of fractional coordinates '''
    for idx, site in enumerate(atmlst):
        for i in range(3):
            if site[1][i] < 0:
                atmlst[idx][1][i] += 1.0
            elif site[1][i] > 1:
                atmlst[idx][1][i] -= 1.0

def _check_options():
    if '-r' in sys.argv:
        print('-r option is ignored.')
    if '-a' in sys.argv:
        print('-a option is ignored.')
    if '-e' in sys.argv:
        print('-e option is ignored.')

class ReadInput(object):
    ''' Read standard input file '''
    def __read_ion_coords(self, infile):
        for line in infile:
            if line.isspace() or line[0] == '#':
                continue
            else:
                itms = line.rstrip().split()
                if itms[0] not in self.ion_name:
                    self.ion_name.append(itms[0])

                self.atmlst.append(list([itms[0],
                                         array(itms[1:4], dtype=np.float64),
                                         float(itms[4])]))

    def __expand_structure(self):
        expn = [1. if axis > 6.0 else 2. for axis in self.latp[:3]]
        # unit = np.zeros((4, 0), dtype=np.float64)
        for site in self.atmlst:
            _ai, _bi, _ci = -expn[0], -expn[1], -expn[2]
            while _ai <= expn[0]:
                while _bi <= expn[1]:
                    while _ci <= expn[2]:
                        self.atmlst_ex.append(list([site[0],
                                                    site[1] + array([_ai, _bi, _ci]),
                                                    site[2]]))
                        _ci += 1.
                    _ci = -expn[2]
                    _bi += 1.
                _bi = -expn[1]
                _ai += 1.

    def __check_parameters(self):
        if len(self.formal_charge) != self.nion:
            raise Exception("No. of formal charge values does not match with the No. of ions.")
        if len(self.d_0) != self.nion:
            raise Exception("No. of D_0 values does not match with the No. of ions.")
        if len(self.rmin) != self.nion:
            raise Exception("No. of R_min values does not match with the No. of ions.")
        if len(self.alpha) != self.nion:
            raise Exception("No. of alpha values does not match with the No. of ions.")
        if len(self.rcov) != self.nion:
            raise Exception("No. of covalent-radius values does not match with the No. of ions.")
        if len(self.ion_name) != self.nion:
            raise Exception("No. of ion species does not match with the setting in your file.")

    def __init__(self, fname):
        _check_options()
        try:
            infile = open(fname, 'r')
        except IOError as err:
            print(err)
            sys.exit()

        self.flag_bvel = False
        self.title = _readinpline(infile)
        if self.title.split()[-1] == 'BVEL':
            self.flag_bvel = True
            print('The BVEL flag was detected.')

        self.latp = [float(x) for x in _readinpline(infile).split()]

        self.atmlst = list()
        self.ion_name = list()

        if self.flag_bvel:  # BVEL Mode
            try:
                self.t_ion = _readinpline(infile)
                self.t_charge = float(_readinpline(infile))
                self.t_rcov = float(_readinpline(infile))
                self.nion = int(_readinpline(infile))
                self.formal_charge = [float(x) for x in _readinpline(infile).split()]
                self.d_0 = [float(x) for x in _readinpline(infile).split()]
                self.rmin = [float(x) for x in _readinpline(infile).split()]
                self.alpha = [float(x) for x in _readinpline(infile).split()]
                self.rcov = [float(x) for x in _readinpline(infile).split()]
                self.resl = [int(x) for x in _readinpline(infile).split()]
            except (ValueError, AttributeError, TypeError) as err:
                print('The input file has some problems.')
                print(err)
                sys.exit()

            self.grid_size = self.resl[0] * self.resl[1] * self.resl[2]

            self.__read_ion_coords(infile)
            _normalize(self.atmlst)  # Normalize F.C.

            # Generate expanded atom list
            self.atmlst_ex = list()  # initialize
            self.__expand_structure()
            try:
                self.__check_parameters()
            except Exception as err:
                print(err)
                sys.exit()

        else:  # Conventional BVS
            try:
                self.ival = float(_readinpline(infile))
                self.cinum = int(_readinpline(infile))
            except (ValueError, TypeError) as err:
                print(err)
                sys.exit()

            self.cisp = list()
            self.bvplst = list()
            i = 0
            while i < self.cinum:
                bvp = _readinpline(infile).split()
                if len(bvp) != 3:
                    print('The BVS parameters have some problems')
                    sys.exit()
                self.cisp.append(bvp[0])
                self.bvplst.append([float(x) for x in bvp[1:]])
                i += 1

            try:
                self.resl = [int(x) for x in _readinpline(infile).split()]
            except ValueError as err:
                print(err)
                sys.exit()

            self.__read_ion_coords(infile)

        infile.close()


def writepgrid(fname, inp, mapdata):
    ''' Output *.pgrid file '''
    with open(fname, 'wb') as outf:
        outf.write(pack('4i', 3, 0, 0, 0))  # file format version
        outf.write(pack('80s', inp.title.ljust(80).encode('utf-8')))  # Title 80 characters
        outf.write(pack('i', 1))  # gType 0 for *.ggrid, 1 for *.pgrid
        outf.write(pack('i', 0))  # fType 0
        outf.write(pack('i', 1))  # nVal dummy
        outf.write(pack('i', 3))  # dimension
        outf.write(pack('3i', *mapdata.shape))  # numbers of voxels
        outf.write(pack('i', mapdata.size))  # Total number of voxels
        outf.write(pack('6f', *inp.latp))  # lattice parameters
        for k in range(mapdata.shape[2]):
            for j in range(mapdata.shape[1]):
                for i in range(mapdata.shape[0]):
                    outf.write(pack('f', mapdata[i, j, k]))


def writegrd(fname, inp, mapdata):
    ''' Output *.grd file '''
    with open(fname, 'w') as bvf:
        bvf.write('%s\n' % (inp.title))
        bvf.write('%f  %f  %f  %f  %f  %f\n' % tuple(inp.latp))
        bvf.write('%i  %i  %i\n' % mapdata.shape)
        idx = 0
        for i, _x in np.ndenumerate(mapdata):
            bvf.write('  %.10e' % (_x))
            idx += 1
            if idx == 6 or i[2] == mapdata.shape[2]-1:
                bvf.write('\n')
                idx = 0
