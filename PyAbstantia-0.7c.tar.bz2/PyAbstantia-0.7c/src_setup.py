from distutils.core import setup
''' setup file for source distribution '''

setup(name='PyAbstantia',
      description='BVS map calculation program',
      long_description='BVS map calculation program',
      version='0.7c',
      author='Shinichi NISHIMURA',
      license='MIT License',
      author_email='nishimura@chemsys.t.u-tokyo.ac.jp',
      url='https://shinichinishimura.github.io/pyabst',
      py_modules=['pyabst', 'cal_bvsm', 'cal_bvel', 'fileio',
                  'dict_R_cov', 'dict_BVEL', 'dict_BVS'],
      data_files=['LICENSE', 'INSTALL', 'src/bvs.f90', 'src/bvel.f90', 'build_lib.sh']
     )
