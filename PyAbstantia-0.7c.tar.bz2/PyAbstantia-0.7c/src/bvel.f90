! BVEL
subroutine bvel_morse(grid_size, d_0, rmin, al, occ, ion_pos, gridx, gridy, gridz, bvel)
    implicit none
    integer, intent(in) :: grid_size
    double precision, intent(in) :: d_0
    double precision, intent(in) :: rmin
    double precision, intent(in) :: al
    double precision, intent(in) :: occ
    double precision, dimension(3), intent(in) :: ion_pos
    double precision, dimension(grid_size), intent(in) :: gridx, gridy, gridz 
    double precision, dimension(grid_size), intent(inout) :: bvel

    double precision :: rr
    integer :: i

    do i = 1, grid_size
        rr = sqrt( (ion_pos(1)-gridx(i))**2 &
                 + (ion_pos(2)-gridy(i))**2 &
                 + (ion_pos(3)-gridz(i))**2 )
        bvel(i) = bvel(i) + occ * d_0 * ((exp(al*(rmin-rr)) - 1)**2 - 1)
    end do
end subroutine


subroutine bvel_repulsion(grid_size, q0, q1, r0, r1, ion_pos, gridx, gridy, gridz, bvel)
    implicit none
    integer, intent(in) :: grid_size
    double precision, intent(in) :: q0, q1
    double precision, intent(in) :: r0, r1
    double precision, dimension(3), intent(in) :: ion_pos
    double precision, dimension(grid_size), intent(in) :: gridx, gridy, gridz 
    double precision, dimension(grid_size), intent(inout) :: bvel

    double precision :: rr
    double precision :: rho_i
    integer :: i

    rho_i = 1.0d0 / 0.74d0 / (r0+r1)
    do i = 1, grid_size
        rr = sqrt( (ion_pos(1)-gridx(i))**2 &
                 + (ion_pos(2)-gridy(i))**2 &
                 + (ion_pos(3)-gridz(i))**2 )
        bvel(i) = bvel(i) + q0 * q1 / rr * erfc(rr*rho_i)
    end do
end subroutine
