#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
PyAbstantia

3D bond-valence sum calculation program
(S.Adams, Acta Cryst. B57(2001)278)

Author: Shinichi NISHIMURA

ctypes version
ver.0.3.1
2015/09/18
ver.0.5
2017/06/26
ver.0.6
2017/06/28
ver.0.7
2017/07/05
'''
from multiprocessing import Pool
import time
import sys
from numpy import zeros, dot, mgrid, absolute
from numpy import split, concatenate
# Local modules
from fileio import *
from cal_bvsm import *
from cal_bvel import *

# pylint: disable=invalid-name

def _bvel_cycle(gridxyz, inp, lat_mat):
    t_charge = inp.t_charge
    bvel_map_s = zeros(gridxyz[0].size)
    for ion in inp.atmlst_ex:
        form_charge = inp.formal_charge[inp.ion_name.index(ion[0])]
        if ion[0] == inp.t_ion:
            continue
        elif (form_charge < 0 and t_charge > 0) or (form_charge > 0 and t_charge < 0):
            ion[1] = dot(lat_mat, ion[1])
            cal_bvel(inp, ion, gridxyz, bvel_map_s)
            #cal_bvel_f2py(inp, ion, gridxyz, bvel_map_s)
        else:
            ion[1] = dot(lat_mat, ion[1])
            cal_bvel_repulsion(inp, ion, gridxyz, bvel_map_s)
            #cal_bvel_repulsion_f2py(inp, ion, gridxyz, bvel_map_s)

    return bvel_map_s

def _bvel_run():
    print('Running in BVEL mode')
    print('Target: {}'.format(inp.t_ion))
    fmt = '{:4s}{:5s}{:7s}{:7s}{:7s}{:7s}'
    print(fmt.format('Ion', ' q', ' R_min', ' D_0', ' alpha', ' R_cov'))
    fmt = '{:4s}{:5.2f}{:7.4f}{:7.4f}{:7.4f}{:7.4f}'
    for i in range(len(inp.ion_name)):
        print(fmt.format(inp.ion_name[i], inp.formal_charge[i], inp.rmin[i],
                         inp.d_0[i], inp.alpha[i], inp.rcov[i]))

    start = time.time()
    gridx = zeros(inp.grid_size)
    gridy = zeros(inp.grid_size)
    gridz = zeros(inp.grid_size)
    gridx = grid_coords[0, :, :, :].flatten()
    gridy = grid_coords[1, :, :, :].flatten()
    gridz = grid_coords[2, :, :, :].flatten()

    if mp > 0:
        gmp_x = split(gridx, mp)
        gmp_y = split(gridy, mp)
        gmp_z = split(gridz, mp)
        p = Pool(processes=mp)
        print('multiprocessing')
        #outputs = p.map(_bvel_cycle, [[gmp_x[i], gmp_y[i], gmp_z[i]] for i in range(mp)])
        mpresults = [p.apply_async(_bvel_cycle, args=([gmp_x[i], gmp_y[i], gmp_z[i]], inp, lat_mat))
                     for i in range(mp)]
        outputs = [result.get() for result in mpresults]
        bvel_map = concatenate(outputs)
    else:
        print('serial mode')
        bvel_map = _bvel_cycle([gridx, gridy, gridz], inp, lat_mat)

    if len(sys.argv) > 2 and '-t' in sys.argv:
        print('Output file: {0}.grd'.format(OUTFILE))
        writegrd(OUTFILE+'.grd', inp, bvel_map.reshape(resl))
    else:
        print('Output file: {0}.pgrid'.format(OUTFILE))
        writepgrid(OUTFILE+'.pgrid', inp, bvel_map.reshape(resl))

    print('----------------------------------------')
    print('Calculation time for 3D-BVEL: {0:6.2f} sec'.format(time.time() - start))
    print('done')

def _bvs_run():
    start = time.time()
    bvsm = zeros(resl)
    for i in range(inp.cinum):
        cilst = gencilst(inp.atmlst, latp, lat_mat, inp.cisp[i])
        if mp > 0:
            grdcmp = split(grid_coords, mp, axis=3)
            p = Pool(processes=mp)
            #mpresults = [p.apply_async(calbvm_f2py, args=(inp.bvplst[i],
            mpresults = [p.apply_async(calbvm, args=(inp.bvplst[i],
                                                     cilst, grdcmp[j]))
                         for j in range(mp)]
            outputs = [result.get() for result in mpresults]
            bvsm += concatenate(outputs, axis=2)
        else:
            bvsm += calbvm(inp.bvplst[i], cilst, grid_coords)
            #bvsm += calbvm_f2py(inp.bvplst[i], cilst, grid_coords)

    vmm = absolute(bvsm - inp.ival)  # Delta V

    if len(sys.argv) > 2 and '-t' in sys.argv:
        print('Output file: {0}.grd'.format(OUTFILE))
        writegrd(OUTFILE+'.grd', inp, vmm)
    else:
        print('Output file: {0}.pgrid'.format(OUTFILE))
        writepgrid(OUTFILE+'.pgrid', inp, vmm)

    print('----------------------------------------')
    print('Calculation time for 3D-BVS: {0:6.2f} sec'.format(time.time() - start))
    print('done')

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('No input file was specified.')
        print('Usage:')
        print('pyabst [OPITONS] [INPUT_FILE]')
        sys.exit()

    INPFILE = sys.argv[-1]  # The last argv must be the input file name.
    if len(sys.argv[-1].split('.')) == 1:
        OUTFILE = INPFILE
    else:
        OUTFILE = '.'.join(INPFILE.split('.')[:-1])

    print('Input file: {0}'.format(INPFILE))
    if INPFILE.split('.')[-1] == 'cif' or INPFILE.split('.')[-1] == 'CIF':
        inp = ReadCIF(INPFILE)
        inp.write_inp(OUTFILE+'.inp')
        print('-----------------------------------------')
        print('{} was generated.'.format(OUTFILE+'.inp'))
        if '-e' in sys.argv:
            inp.write_bvel_inp(OUTFILE+'_BVEL.inp')
        print('{} was generated.'.format(OUTFILE+'_BVEL.inp'))
        print('-----------------------------------------')
    else:
        inp = ReadInput(INPFILE)  # Input file reader class

    print('Title: {0}'.format(inp.title))
    latp = inp.latp
    print('Lattice Parameters:')
    print(' a = {} Å, b = {} Å, c = {} Å'.format(*latp[:3]))
    print('alpha = {}°, beta = {}°, gamma = {}°'.format(*latp[3:]))
    resl = inp.resl
    print('Data points along each axes: {} {} {}'.format(*resl))

    if len(sys.argv) > 2 and '-mp' in sys.argv:
        try:
            mp = int(sys.argv[sys.argv.index('-mp')+1])
        except ValueError:
            print('!!!!!!!!!!   Error   !!!!!!!!!!!!!!!!!!!!!!!!!!')
            print('Input an integer number after the \"-mp\" option.')
            sys.exit()
        print('Number of Processes: {}'.format(mp))
    else:
        mp = 0

    lat_mat = latmat(latp)  # lattice matrix
    grxyz = mgrid[0:1:(resl[0]+1)*1j,
                  0:1:(resl[1]+1)*1j,
                  0:1:(resl[2]+1)*1j]
    grxyz = grxyz[:, :resl[0], :resl[1], :resl[2]]  # trim boundary points
    grid_coords = dot(lat_mat, grxyz.swapaxes(0, 2)).swapaxes(1, 2)
    grid_coords.flags.writeable = False

    if inp.flag_bvel:  # Calculation of BVEL map
        while mp != 0 and inp.grid_size % mp != 0:
            mp -= 1
            print('Multiprocessing is not applicable.')
            print('No. of processes was reduced to {}.'.format(mp))
        
        _bvel_run()

    else:  # Calculation of conventional BVS map
        while mp != 0 and resl[2] % mp != 0:
            mp -= 1
            print('Multiprocessing is not applicable.')
            print('No. of processes was reduced to {}.'.format(mp))

        _bvs_run()
