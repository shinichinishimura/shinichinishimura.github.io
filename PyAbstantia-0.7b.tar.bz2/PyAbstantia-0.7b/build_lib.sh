#!/bin/bash
set -eu

# Set Fortran compiler
FC=gfortran
#FC=ifort

if [ ${FC} = 'gfortran' ]; then
    OPT="-O2"
    ARCH="-march=native"
    LINK="-shared -fPIC"
elif [ ${FC} = "ifort" ]; then
    OPT="-O3"
    ARCH="-xHost"
    if [ "$(uname)" = 'Darwin' ]; then
        LINK="-dynamiclib"
    else
        LINK="-shared -fPIC"
    fi
else
    echo "Use gfortran or ifort."
    exit 1
fi

#f2py -c --f90exec=${FC} --opt="${OPT}" --arch=${ARCH} ${LINK} ./src/bvs_f2py.f90 -m bvs_f2py
#f2py -c --f90exec=${FC} --opt="${OPT}" --arch=${ARCH} ${LINK} ./src/bvel_f2py.f90 -m bvel_f2py
sources=(bvs bvel)
for src in ${sources[@]}; do
    ${FC} ${OPT} ${ARCH} ${LINK} -o ${src}.so src/${src}.f90
    echo ${src}.so
done
echo "Fortran libraries were generated."
