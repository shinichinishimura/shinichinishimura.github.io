import os
from ctypes import POINTER, byref
from ctypes import c_int, c_void_p, c_double
from numpy import ctypeslib
import numpy as np

bvel_lib = 'bvel.so'
try:
    bvel_ctypes = ctypeslib.load_library(bvel_lib, os.path.abspath(os.path.dirname(__file__)))
except:
    print('bvel.so was not found.')

bvel_ctypes.bvel_morse_.argtypes = [
    POINTER(c_int),
    POINTER(c_double),
    POINTER(c_double),
    POINTER(c_double),
    POINTER(c_double),
    ctypeslib.ndpointer(dtype=np.float64),
    ctypeslib.ndpointer(dtype=np.float64),
    ctypeslib.ndpointer(dtype=np.float64),
    ctypeslib.ndpointer(dtype=np.float64),
    ctypeslib.ndpointer(dtype=np.float64)]
bvel_ctypes.bvel_morse_.restype = c_void_p

bvel_ctypes.bvel_repulsion_.argtypes = [
    POINTER(c_int),
    POINTER(c_double),
    POINTER(c_double),
    POINTER(c_double),
    POINTER(c_double),
    ctypeslib.ndpointer(dtype=np.float64),
    ctypeslib.ndpointer(dtype=np.float64),
    ctypeslib.ndpointer(dtype=np.float64),
    ctypeslib.ndpointer(dtype=np.float64),
    ctypeslib.ndpointer(dtype=np.float64)]
bvel_ctypes.bvel_repulsion_.restype = c_void_p

def cal_bvel(input_param, ion, grid, bvel_map):
    ''' Calculation of BVEL by ctypes '''
    ion_id = input_param.ion_name.index(ion[0])  # ID of current ion
    c_grid_size = c_int(bvel_map.size)
    c_d_0 = c_double(input_param.d_0[ion_id])
    c_rmin = c_double(input_param.rmin[ion_id])
    c_alpha = c_double(input_param.alpha[ion_id])
    c_occ = c_double(ion[2])
    bvel_ctypes.bvel_morse_(
        byref(c_grid_size),
        byref(c_d_0),
        byref(c_rmin),
        byref(c_alpha),
        byref(c_occ),
        np.asarray(ion[1], dtype=np.float64),
        grid[0],
        grid[1],
        grid[2],
        bvel_map)


def cal_bvel_repulsion(input_param, ion, grid, bvel_map):
    ''' Calculation of screened electrostatic repulsion '''
    ion_id = input_param.ion_name.index(ion[0])  # ID of current ion
    c_grid_size = c_int(bvel_map.size)
    c_q0 = c_double(input_param.t_charge)
    c_q1 = c_double(input_param.formal_charge[ion_id])
    c_r0 = c_double(input_param.t_rcov)
    c_r1 = c_double(input_param.rcov[ion_id])
    bvel_ctypes.bvel_repulsion_(
        byref(c_grid_size),
        byref(c_q0),
        byref(c_q1),
        byref(c_r0),
        byref(c_r1),
        np.asarray(ion[1], dtype=np.float64),
        grid[0],
        grid[1],
        grid[2],
        bvel_map)
