# -*- coding: utf-8 -*-
from struct import pack
import sys
import warnings
import numpy as np
from numpy import array


class ReadCIF(object):
    ''' Read CIF by CifParser of pymatgen '''
    def __init__(self, fname):
        try:
            from pymatgen.io.cif import CifParser
        except ImportError:
            print('Pymatgen was not found.\nInstall pymatgen for handling CIF.')
            sys.exit()
        self.flag_bvel = False
        print('--- CIF mode ---')
        cif = open(fname, 'r')
        for line in cif:
            if line.startswith('data_'):
                self.title = "_".join(line.strip().split('_')[1:])
                break
        cif.close()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            cifp = CifParser(fname)

        struct = cifp.get_structures(primitive=False)[0]
        self.latp = struct.lattice.abc + struct.lattice.angles
        self.atmlst = list()
        for site in struct.sites:
            if len(site.species_string.split(',')) > 1:
                for species in site.species_string.split(','):
                    items = species.strip().split(':')
                    self.atmlst.append(list([items[0],
                                             site.frac_coords,
                                             float(items[1])]))
            else:
                self.atmlst.append(list([_sp_occ(site)[0],
                                         site.frac_coords,
                                         float(_sp_occ(site)[1])]))
        print('Input a formal valence number of target ion.')
        if sys.version_info.major < 3:
            self.ival = float(raw_input())
        else:
            self.ival = float(input())
        print('Input a number of species for counter ion.')
        if sys.version_info.major < 3:
            self.cinum = int(raw_input())
        else:
            self.cinum = int(input())
        print('Input counter ion species and BV parameters, R_0 and b.')
        print('Example:')
        print('O 1.5602 0.475')
        self.cisp = list()
        self.bvplst = list()
        for i in range(self.cinum):
            if sys.version_info.major < 3:
                _stdinp = raw_input()
            else:
                _stdinp = input()
            self.cisp.append(_stdinp.split()[0])
            self.bvplst.append([float(x) for x in _stdinp.split()[1:]])
        print('Input numbers of voxels along a, b and c axes.')
        if sys.version_info.major < 3:
            _stdinp = raw_input()
        else:
            _stdinp = input()
        self.resl = [int(x) for x in _stdinp.split()]

    def writeinp(self, fname):
        ''' Write *.inp file '''
        _f = open(fname, 'w')
        _f.write(self.title+'\n')
        _f.write('{} {} {} {} {} {}\n'.format(*self.latp))
        _f.write('{}\n'.format(self.ival))
        _f.write('{}\n'.format(self.cinum))

        for i in range(self.cinum):
            _f.write('{} '.format(self.cisp[i]))
            _f.write('{} {}\n'.format(*self.bvplst[i]))

        _f.write('{} {} {}\n'.format(*self.resl))

        for site in self.atmlst:
            items = [site[0], site[1][0], site[1][1], site[1][2], site[2]]
            _f.write('{:<4} {:8.5f} {:8.5f} {:8.5f} {:6.3f}\n'.format(*items))
        _f.close()


def _sp_occ(psite):
    species = psite.species_string
    if ':' in species:
        return species.split(':')
    return [species, '1.0']

def _readinpline(file):
    ''' Read a line after skiping blank lines and comments '''
    for line in file:
        if line.isspace() or line.strip()[0] == '#':
            continue
        else:
            return line.rstrip()

def _standardize(atmlst):
    ''' Normalization of fractional coordinates '''
    for idx, site in enumerate(atmlst):
        for i in range(3):
            if site[1][i] < 0:
                atmlst[idx][1][i] += 1.0
            elif site[1][i] > 1:
                atmlst[idx][1][i] -= 1.0


class ReadInput(object):
    ''' Read standard input file '''
    def __init__(self, fname):
        self.inpfile = fname
        infile = open(self.inpfile, 'r')
        self.flag_bvel = False
        self.title = _readinpline(infile)
        if self.title.split()[-1] == 'BVEL':
            self.flag_bvel = True
            print('The BVEL flag was detected.')

        self.latp = [float(x) for x in _readinpline(infile).split()]

        if self.flag_bvel:  # BVEL Mode
            self.t_ion = _readinpline(infile)
            self.t_charge = float(_readinpline(infile))
            self.t_rcov = float(_readinpline(infile))
            self.nion = int(_readinpline(infile))
            self.formal_charge = [float(x) for x in _readinpline(infile).split()]
            if len(self.formal_charge) != self.nion:
                print("No. of formal charge values does not match with the No. of ions.")
                sys.exit()

            self.d_0 = [float(x) for x in _readinpline(infile).split()]
            if len(self.d_0) != self.nion:
                print("No. of D_0 values does not match with the No. of ions.")
                sys.exit()

            self.rmin = [float(x) for x in _readinpline(infile).split()]
            if len(self.rmin) != self.nion:
                print("No. of D_0 values does not match with the No. of ions.")
                sys.exit()

            self.alpha = [float(x) for x in _readinpline(infile).split()]
            if len(self.alpha) != self.nion:
                print("No. of alpha values does not match with the No. of ions.")
                sys.exit()

            self.rcov = [float(x) for x in _readinpline(infile).split()]
            if len(self.rcov) != self.nion:
                print("No. of covalent radius values does not match with the No. of ions.")
                sys.exit()

            self.resl = [int(x) for x in _readinpline(infile).split()]
            self.grid_size = self.resl[0] * self.resl[1] * self.resl[2]

            self.atmlst = list()
            self.ion_name = list()
            for line in infile:
                if line.isspace() or line[0] == '#':
                    continue
                else:
                    itms = line.rstrip().split()
                    if itms[0] not in self.ion_name:
                        self.ion_name.append(itms[0])

                    self.atmlst.append(list([itms[0],
                                             array(itms[1:4], dtype=np.float64),
                                             float(itms[4])]))

            if len(self.ion_name) != self.nion:
                print("No. of ion species does not match with the setting in your file.")
                sys.exit()

            _standardize(self.atmlst)  # Normalize F.C.

            # Generate expanded atom list
            self.atmlst_ex = list()
            expn = [1. if axis > 6.0 else 2. for axis in self.latp[:3]]
            # unit = np.zeros((4, 0), dtype=np.float64)
            for site in self.atmlst:
                _ai, _bi, _ci = -expn[0], -expn[1], -expn[2]
                while _ai <= expn[0]:
                    while _bi <= expn[1]:
                        while _ci <= expn[2]:
                            self.atmlst_ex.append(list([site[0],
                                                        site[1] + array([_ai, _bi, _ci]),
                                                        site[2]]))
                            _ci += 1.
                        _ci = -expn[2]
                        _bi += 1.
                    _bi = -expn[1]
                    _ai += 1.

        else:  # Conventional BVS
            self.ival = float(_readinpline(infile))
            self.cinum = int(_readinpline(infile))

            self.cisp = list()
            self.bvplst = list()
            for i in range(self.cinum):
                bvp = _readinpline(infile).split()
                self.cisp.append(bvp[0])
                self.bvplst.append([float(x) for x in bvp[1:]])

            self.resl = [int(x) for x in _readinpline(infile).split()]

            self.atmlst = list()
            for line in infile:
                if line.isspace() or line[0] == '#':
                    continue
                else:
                    itms = line.rstrip().split()
                    self.atmlst.append(list([itms[0],
                                             array(itms[1:4], dtype=np.float64),
                                             float(itms[4])]))
        infile.close()


def writepgrid(fname, inp, mapdata):
    ''' Output *.pgrid file '''
    with open(fname, 'wb') as outf:
        outf.write(pack('4i', 3, 0, 0, 0))  # file format version
        outf.write(pack('80s', inp.title.ljust(80).encode('utf-8')))  # Title 80 characters
        outf.write(pack('i', 1))  # gType 0 for *.ggrid, 1 for *.pgrid
        outf.write(pack('i', 0))  # fType 0
        outf.write(pack('i', 1))  # nVal dummy
        outf.write(pack('i', 3))  # dimension
        outf.write(pack('3i', *mapdata.shape))  # numbers of voxels
        outf.write(pack('i', mapdata.size))  # Total number of voxels
        outf.write(pack('6f', *inp.latp))  # lattice parameters
        for k in range(mapdata.shape[2]):
            for j in range(mapdata.shape[1]):
                for i in range(mapdata.shape[0]):
                    outf.write(pack('f', mapdata[i, j, k]))


def writegrd(fname, inp, mapdata):
    ''' Output *.grd file '''
    with open(fname, 'w') as bvf:
        bvf.write('%s\n' % (inp.title))
        bvf.write('%f  %f  %f  %f  %f  %f\n' % tuple(inp.latp))
        bvf.write('%i  %i  %i\n' % mapdata.shape)
        idx = 0
        for i, _x in np.ndenumerate(mapdata):
            bvf.write('  %.10e' % (_x))
            idx += 1
            if idx == 6 or i[2] == mapdata.shape[2]-1:
                bvf.write('\n')
                idx = 0
