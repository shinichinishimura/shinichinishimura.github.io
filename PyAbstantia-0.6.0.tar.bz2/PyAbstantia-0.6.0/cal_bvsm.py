from ctypes import CDLL, cdll, POINTER, byref, c_double
from ctypes import c_int, c_void_p, c_int64
from numpy import array, dot, zeros, ndenumerate, float64, ctypeslib
from numpy.ctypeslib import load_library
from numpy import r_, c_, vstack, hstack, int64, apply_along_axis
from math import radians, sin, cos, sqrt
# math functions are faster than numpy's fuctions
# from numpy import radians,sin,cos,sqrt
from os import path
import numpy as np

bvslib = 'bvs.so'
bvs_ctypes = load_library(bvslib, path.abspath(path.dirname(__file__)))

bvs_ctypes.calbvs_.argtypes = [
    POINTER(c_double),
    POINTER(c_double),
    POINTER(c_double),
    ctypeslib.ndpointer(dtype=float64),
    POINTER(c_int),
    ctypeslib.ndpointer(dtype=float64)]
bvs_ctypes.calbvs_.restype = c_void_p


def latmat(latp):
    a, b, c, al, be, ga = latp
    alr, ber, gar = radians(al), radians(be), radians(ga)
    V = a*b*c*sqrt(1 - cos(alr)**2 - cos(ber)**2 - cos(gar)**2 +
                   2*cos(alr)*cos(ber)*cos(gar))
    l1, l2, l3 = a, 0, 0
    m1, m2, m3 = b*cos(gar), b*sin(gar), 0
    n1 = c*cos(ber)
    n2 = c*(cos(alr)-cos(ber)*cos(gar))/sin(gar)
    n3 = V/(a*b*sin(gar))
    return array([[l1, m1, n1], [l2, m2, n2], [l3, m3, n3]], dtype=float64)


def standardize(x):
    if x < 0.0:
        x = 1.0 + x
    return x


def gencilst(atmlst, latp, lmat, cion):
    expn = [1. if axis > 6.0 else 2. for axis in latp[:3]]
    unit = zeros((4, 0), dtype=float64)
    for site in atmlst:
        if site[0] == cion:
            site[1] = [standardize(x) for x in site[1]]
            unit = c_[unit, r_[site[1], site[2]]]
    cilst = zeros((4, 0), dtype=float64)
    ai, bi, ci = -expn[0], -expn[1], -expn[2]
    while ai <= expn[0]:
        while bi <= expn[1]:
            while ci <= expn[2]:
                shifted = unit.copy()
                shifted[:3, :] += array([ai, bi, ci]).reshape(3, 1)
                cilst = c_[cilst, shifted]
                ci += 1.
            ci = -expn[2]
            bi += 1.
        bi = -expn[1]
        ai += 1.
    cilst[:3, :] = dot(lmat, cilst[:3, :])
    return cilst.T.copy()


def calbvm(lmat, bvprm, cilst, grxyz):
    # definitions for ctypes
    bvs = c_double(0.0)
    rzr = c_double(bvprm[0])  # R_0
    bbv = c_double(1/bvprm[1])  # 1/B
    cnum = c_int(cilst.shape[0])  # Number of counter ion
    # matrix for BVS map
    grx, gry, grz = grxyz
    bvm = zeros(grxyz.shape[1:])  # 3D array for BVS
    for i, x in ndenumerate(grx):
        grdp = grxyz[:, i[0], i[1], i[2]].copy()
        # BVS calculation
        bvs_ctypes.calbvs_(byref(bvs), byref(rzr), byref(bbv),
                           grdp, byref(cnum), cilst)
        bvm[i] = bvs.value
    return bvm


def calbvs(pcart, lmat, bvprm, cilst):
    # definitions for ctypes
    bvs = c_double(0.0)
    rzr = c_double(bvprm[0])  # R_0
    bbv = c_double(1/bvprm[1])  # 1/B
    cnum = c_int(cilst.shape[0])  # Number of counter ion
    pcart = array(pcart, dtype=float64)
    # BVS calculation
    bvs_ctypes.calbvs_(byref(bvs), byref(rzr), byref(bbv),
                       pcart, byref(cnum), cilst)
    return bvs.value


def bvsmapnp(lmat, bvprm, cilst, grdc):
    bvm = apply_along_axis(calbvs, 1, grdc.T.reshape(-1, 3),
                           lmat, bvprm, cilst)
    return bvm.reshape(grdc.shape[3], grdc.shape[2], grdc.shape[1]).T


def bvsmap(lmat, grdc, bvprm, cilst):
    resx, resy, resz = grdc.shape[1:]
    bvm = [calbvs(grdc[:, i, j, k], lmat, bvprm, cilst)
           for i in range(resx) for j in range(resy) for k in range(resz)]
    return array(bvm, dtype=float64).reshape(grdc.shape[1:])
