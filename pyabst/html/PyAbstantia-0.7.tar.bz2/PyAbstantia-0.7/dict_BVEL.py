''''
Dictionary of BVEL parameters
D_0, R_min, alpha

These parameter are taken from the following paper:
S. Adams and R.P. Rao, 
"High power lithium ion battery materials by computational design"
Phys. Status Solidi A 208(8), 1746--1753 (2011)

'''

dict_BVEL = {"LiO":[0.98816, 1.94001, 1.937984],
             "NaO":[0.57523, 2.37433, 2.074689]}
