! bvs_omp.f90

subroutine calbvs(bvs, r_0, b_bv, vec_grdp, onum, opos)
    !$ use omp_lib
    implicit none
    double precision,intent(out) :: bvs
    double precision,intent(in) :: r_0
    double precision,intent(in) :: b_bv
    double precision,dimension(3),intent(in) :: vec_grdp
    integer,intent(in) :: onum
    double precision,dimension(4,onum),intent(in) :: opos
    double precision bv,rr
    integer i

    bvs = 0.0d0
    do i = 1,onum
        rr = sqrt((opos(1,i)-vec_grdp(1))**2+(opos(2,i)-vec_grdp(2))**2+(opos(3,i)-vec_grdp(3))**2)
        if (rr < 0.5d0) then
            bvs = 100.0d0
            !exit
        else if (rr < 6.0d0) then
            bv = opos(4,i) * exp((r_0-rr)*b_bv)
            bvs = bvs + bv 
        endif    
    enddo
end subroutine

